package com.springboot.services;

import com.springboot.dto.UserDto;
import com.springboot.entity.User;

public interface UserService {
 User findByUsername(String username);

 User save(UserDto userDto);

}