package com.springboot.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.dto.UserDto;
import com.springboot.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

 User findByUsername(String username);

 User save(UserDto userDto);
}